# GULLAK--Personal-Memory-Vault
GULLAK is a MERN (MongoDB, Express, React, Node.js) web application that allows users to store and cherish their memories. Users can add, update, and delete memories, upload photos, and search for memories by a specific person or the with whom they shared the memory.
